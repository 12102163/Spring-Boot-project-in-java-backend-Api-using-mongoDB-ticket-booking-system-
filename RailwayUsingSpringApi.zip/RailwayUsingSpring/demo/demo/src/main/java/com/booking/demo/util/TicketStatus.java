package com.booking.demo.util;

public enum TicketStatus {
    Not_Avalable_seat_Acording_to_user_prefrence,
    Ticket_Booked_Sucssefull,
    Sorouce_And_Destination_trains_Are_not_there,
    Sorry_Tickets_Are_over, UserNull;
}
