package com.booking.demo.util;

public enum LoginStatus {
    Password_Wrong,
    User_Succsefully_logined,
    Email_is_Wrong;
}
